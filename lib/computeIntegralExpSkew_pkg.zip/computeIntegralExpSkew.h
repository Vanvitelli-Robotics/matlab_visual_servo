//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: computeIntegralExpSkew.h
//
// MATLAB Coder version            : 5.1
// C/C++ source code generated on  : 20-Oct-2021 18:22:21
//
#ifndef COMPUTEINTEGRALEXPSKEW_H
#define COMPUTEINTEGRALEXPSKEW_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace sun_vs
{
  extern void computeIntegralExpSkew(double T, double wx, double wy, double wz,
    double inteS[9]);
  extern void computeIntegralExpSkew_initialize();
  extern void computeIntegralExpSkew_terminate();
}

#endif

//
// File trailer for computeIntegralExpSkew.h
//
// [EOF]
//
